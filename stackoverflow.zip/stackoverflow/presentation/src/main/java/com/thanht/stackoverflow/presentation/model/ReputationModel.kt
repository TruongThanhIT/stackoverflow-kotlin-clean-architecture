package com.thanht.stackoverflow.presentation.model

class ReputationModel(
        val reputationHistoryType: String?= null,
        val reputationChanged: Int = 0,
        val postId: Int = 0,
        val createdDate: Long = 0L
)