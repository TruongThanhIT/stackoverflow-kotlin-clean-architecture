package com.thanht.stackoverflow.presentation.di.module

import dagger.Module
import dagger.Provides
import com.thanht.stackoverflow.data.scheduler.WorkSchedulerImpl
import com.thanht.stackoverflow.domain.scheduler.ResultScheduler
import com.thanht.stackoverflow.domain.scheduler.WorkScheduler
import com.thanht.stackoverflow.presentation.scheduler.ResultSchedulerImpl
import javax.inject.Singleton

@Module
class SchedulerModule {
    @Provides
    @Singleton
    internal fun provideWorkScheduler(): WorkScheduler {
        return WorkSchedulerImpl()
    }

    @Provides
    @Singleton
    internal fun provideResultScheduler(): ResultScheduler {
        return ResultSchedulerImpl()
    }
}
