package com.thanht.stackoverflow.presentation.di.module


import dagger.Module
import dagger.Provides
import com.thanht.stackoverflow.data.cache.UserCached
import com.thanht.stackoverflow.data.cache.impl.UserCachedImpl
import com.thanht.stackoverflow.presentation.di.scope.UserScope

@Module
class CachedModule {
    @Provides
    @UserScope
    internal fun provideDataCached(dataCached: UserCachedImpl): UserCached {
        return dataCached
    }
}
