package com.thanht.stackoverflow.presentation.ui.util

import android.content.Context
import android.support.annotation.StringRes
import android.widget.Toast

object UIUtils {
    fun showShortToast(context: Context, msg: CharSequence?) {
        if (msg == null || msg.isEmpty()) return
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun showShortToast(context: Context, @StringRes msg: Int) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }
}
