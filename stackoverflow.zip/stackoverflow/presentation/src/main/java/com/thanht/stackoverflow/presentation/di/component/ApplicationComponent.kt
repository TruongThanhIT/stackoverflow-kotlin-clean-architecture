package com.thanht.stackoverflow.presentation.di.component

import android.content.Context
import dagger.Component
import com.thanht.stackoverflow.data.net.ApiConnection
import com.thanht.stackoverflow.domain.scheduler.ResultScheduler
import com.thanht.stackoverflow.domain.scheduler.WorkScheduler
import com.thanht.stackoverflow.presentation.di.module.ApplicationModule
import com.thanht.stackoverflow.presentation.di.module.NetworkModule
import com.thanht.stackoverflow.presentation.di.module.SchedulerModule
import javax.inject.Singleton

@Singleton
@Component(modules = [ApplicationModule::class, NetworkModule::class, SchedulerModule::class])
interface ApplicationComponent {
    val applicationContext: Context
    fun apiConnection(): ApiConnection
    fun workScheduler(): WorkScheduler
    fun resultScheduler(): ResultScheduler
}
