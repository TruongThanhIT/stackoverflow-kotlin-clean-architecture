package com.thanht.stackoverflow.domain.userlist.requests

class GetUserListParams(val page: Int, val pageSize: Int, val site: String)