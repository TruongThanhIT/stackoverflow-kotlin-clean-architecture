package com.thanht.stackoverflow.domain

const val SITE = "stackoverflow"