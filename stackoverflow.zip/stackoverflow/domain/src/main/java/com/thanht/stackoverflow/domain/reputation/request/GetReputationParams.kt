package com.thanht.stackoverflow.domain.reputation.request

class GetReputationParams(val page: Int, val pageSize: Int, val site: String, val userId: Int)