package com.thanht.stackoverflow.data.scheduler

import io.reactivex.Scheduler
import io.reactivex.schedulers.Schedulers
import com.thanht.stackoverflow.domain.scheduler.WorkScheduler

class WorkSchedulerImpl : WorkScheduler {
    override val scheduler: Scheduler = Schedulers.computation()
}
