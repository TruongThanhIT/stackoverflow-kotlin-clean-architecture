package com.thanht.stackoverflow.data.cache

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.thanht.stackoverflow.data.entity.UserInfoEntity
import javax.inject.Inject

@Database(entities = [UserInfoEntity::class], version = 1, exportSchema = false)
abstract class DatabaseCached @Inject constructor() : RoomDatabase() {

    abstract fun userDao(): UserInfoDao

    companion object {
        // Singleton prevents multiple instances of database opening at the
        // same time.
        @Volatile
        private var INSTANCE: DatabaseCached? = null

        fun getDatabase(context: Context): DatabaseCached {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                        context.applicationContext,
                        DatabaseCached::class.java,
                        "stack_over_flow.db"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}
